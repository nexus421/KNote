import org.commonmark.ext.gfm.strikethrough.StrikethroughExtension
import org.commonmark.ext.gfm.tables.TablesExtension
import org.commonmark.ext.task.list.items.TaskListItemsExtension
import org.commonmark.parser.Parser
import org.commonmark.renderer.html.DefaultUrlSanitizer
import org.commonmark.renderer.html.HtmlRenderer

fun check(name: String, ok: Boolean, detail: String = "") {
    println((if (ok) "PASS " else "FAIL ") + name + if (ok) "" else "\n  -> $detail")
    if (!ok) System.exit(1)
}

fun main() {
    val extensions = listOf(TablesExtension.create(), StrikethroughExtension.create(), TaskListItemsExtension.create())
    val parser = Parser.builder().extensions(extensions).build()
    val renderer = HtmlRenderer.builder().extensions(extensions).escapeHtml(true).sanitizeUrls(true)
        .urlSanitizer(DefaultUrlSanitizer(listOf("http", "https", "mailto"))).build()
    fun render(md: String) = renderer.render(parser.parse(md))

    val table = render("| a | b |\n|---|---|\n| 1 | 2 |")
    check("table rendered", table.contains("<table>") && table.contains("<td>1</td>"), table)

    val strike = render("~~weg~~")
    check("strikethrough rendered", strike.contains("<del>weg</del>"), strike)

    val tasks = render("- [ ] offen\n- [x] erledigt")
    check("task list rendered", tasks.contains("type=\"checkbox\"") && tasks.contains("checked"), tasks)

    val script = render("<script>alert(1)</script>")
    check("raw script block escaped", script.contains("<script>").not() && script.contains("&lt;script&gt;"), script)

    val inline = render("Text <img src=x onerror=alert(1)> mehr")
    check("inline raw html escaped", inline.contains("<img").not(), inline)

    val jsLink = render("[klick](javascript:alert(1))")
    check("javascript link sanitized", jsLink.contains("javascript:").not(), jsLink)
    println("  js link renders as: ${jsLink.trim()}")

    val dataImg = render("![x](data:text/html;base64,PHNjcmlwdD4=)")
    check("data url image sanitized", dataImg.contains("data:text/html").not(), dataImg)
    println("  data image renders as: ${dataImg.trim()}")

    val dataLink = render("[x](data:text/html;base64,PHNjcmlwdD4=)")
    check("data url link sanitized", dataLink.contains("data:").not(), dataLink)
    val relLink = render("[intern](/projekte/knote)")
    check("relative link kept", relLink.contains("href=\"/projekte/knote\""), relLink)

    val normalLink = render("[ok](https://example.org/a?b=c&d=e)")
    check("normal link kept and escaped", normalLink.contains("href=\"https://example.org/a?b=c&amp;d=e\""), normalLink)

    val umlaut = render("# Überschrift Ä ß 😀")
    check("unicode kept", umlaut.contains("Überschrift Ä ß 😀"), umlaut)

    println("ALL MARKDOWN CHECKS PASSED")
}
