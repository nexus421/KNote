@file:OptIn(kotnexlib.ExperimentalKotNexLibAPI::class)

import kotnexlib.crypto.AES
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import javax.crypto.AEADBadTagException
import kotlin.time.measureTimedValue

fun check(name: String, ok: Boolean) {
    println((if (ok) "PASS " else "FAIL ") + name)
    if (!ok) System.exit(1)
}

fun main() {
    val md = "# Einkauf\n\n- Äpfel\n- Brot\n\n| a | b |\n|---|---|\n| 1 | 2 |\n\n😀 emoji"

    for (compress in listOf(false, true)) {
        val (stored, encTime) = measureTimedValue { AES.GCM.encryptWithPassword(md, "geheim", compress = compress).toString() }
        println("encrypt compress=$compress took $encTime, stored length=${stored.length}")

        val (plain, decTime) = measureTimedValue {
            AES.AESData.restore(stored).mapCatching { it.decryptAsString("geheim").getOrThrow() }
        }
        println("decrypt compress=$compress took $decTime")
        check("roundtrip compress=$compress", plain.getOrNull() == md)

        val wrong = AES.AESData.restore(stored).mapCatching { it.decryptAsString("falsch").getOrThrow() }
        check("wrong password fails compress=$compress", wrong.isFailure)
        println("  wrong password exception: ${wrong.exceptionOrNull()?.javaClass?.name}")
        check("wrong password is AEADBadTagException compress=$compress", wrong.exceptionOrNull() is AEADBadTagException)
    }

    // Same text twice gives different ciphertexts (fresh salt and nonce per call)
    val a = AES.GCM.encryptWithPassword(md, "geheim").toString()
    val b = AES.GCM.encryptWithPassword(md, "geheim").toString()
    check("fresh salt and nonce per call", a != b)

    // Garbage input to restore must not throw, it must be a failure
    check("restore garbage is failure", AES.AESData.restore("kein-base64-!!").isFailure)

    // Empty markdown
    val empty = AES.GCM.encryptWithPassword("", "pw").toString()
    check("empty text roundtrip", AES.AESData.restore(empty).mapCatching { it.decryptAsString("pw").getOrThrow() }.getOrNull() == "")

    // Atomic replace in the same directory
    val dir = Files.createTempDirectory("knote")
    val target = dir.resolve("sheet.json")
    Files.writeString(target, "old")
    val tmp = Files.createTempFile(dir, "sheet", ".tmp")
    Files.writeString(tmp, "new")
    Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
    check("atomic move replaces target", Files.readString(target) == "new")
    check("no temp file left", Files.list(dir).count() == 1L)

    // Path validation
    val pathRegex = Regex("^[a-z0-9-]+(/[a-z0-9-]+)*$")
    val good = listOf("einkauf", "projekte/knote", "a-b/c-d/e")
    val bad = listOf("", "/einkauf", "einkauf/", "../etc/passwd", "a//b", "_admin", "Einkauf", "ä", "a b", "a/./b", "a%2fb")
    good.forEach { check("path ok: $it", pathRegex.matches(it)) }
    bad.forEach { check("path rejected: '$it'", pathRegex.matches(it).not()) }
    println("ALL CHECKS PASSED")
}
