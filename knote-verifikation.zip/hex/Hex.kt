import java.security.SecureRandom

fun main() {
    val key = ByteArray(32).also { SecureRandom().nextBytes(it) }.toHexString()
    println("key length=${key.length}")
    val back = key.hexToByteArray()
    println("bytes=${back.size} roundtrip=${back.toHexString() == key}")
    val ipv4 = Regex("^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])$")
    listOf("10.161.1.5", "255.255.255.255", "0.0.0.0").forEach { check(ipv4.matches(it)) { it } }
    listOf("256.1.1.1", "10.1.1", "01.2.3.4", "fd42::1", "10.1.1.1 ").forEach { check(ipv4.matches(it).not()) { it } }
    println("PASS ipv4 regex")
}
