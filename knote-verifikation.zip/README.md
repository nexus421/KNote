# KNote verification sources

Throwaway checks behind the [T] marks in `KNote-Konzept.md`. Not project code. Built without Gradle, because Maven
Central was not reachable from the verification machine.

## Toolchain used

- kotlinc 2.4.20 from `https://github.com/JetBrains/kotlin/releases/download/v2.4.20/kotlin-compiler-2.4.20.zip`
- OpenJDK 21.0.12 (not Corretto 25)

## Libraries compiled from source

| Library | Tag | What was compiled |
| --- | --- | --- |
| KotNexLib | `v4.4.1` | `Annotations.kt ByteArrayExtensions.kt StringExtensions.kt ResultOf.kt ArgsInterpreter.kt GenericExtensions.kt OtherExtensions.kt BooleanExtensions.kt crypto/AES.kt` |
| commonmark-java | `commonmark-parent-0.30.1` | `commonmark`, `commonmark-ext-gfm-tables`, `commonmark-ext-gfm-strikethrough`, `commonmark-ext-task-list-items` with `javac` |
| kotlinx.serialization | `v1.11.0` | `core` and `formats/json` (common plus jvm sources), with `stub/Language.kt` standing in for the JetBrains annotations artifact, and `Implementation-Version: 1.11.0` added to the jar manifest so the compiler plugin accepts it |

## Run

```bash
kotlinc CryptoCheck.kt -cp kotnexlib-subset.jar -include-runtime -d crypto.jar
java -cp crypto.jar:kotnexlib-subset.jar CryptoCheckKt

kotlinc MarkdownCheck.kt -cp commonmark-0.30.1-local.jar -include-runtime -d md.jar
java -cp md.jar:commonmark-0.30.1-local.jar MarkdownCheckKt

CP=kser-core.jar:kser-json.jar:kotnexlib-subset.jar
kotlinc -Xplugin=<kotlinc>/lib/kotlinx-serialization-compiler-plugin.jar -cp $CP proto/SheetStore.kt proto/StoreCheck.kt -d store.jar
java -cp store.jar:$CP:<kotlinc>/lib/kotlin-stdlib.jar StoreCheckKt

kotlinc -Xplugin=<kotlinc>/lib/kotlinx-serialization-compiler-plugin.jar -cp $CP:<kotlinc>/lib/kotlinx-coroutines-core-jvm.jar proto/SheetStore.kt proto/CryptoGateCheck.kt -d gate.jar
java -cp gate.jar:$CP:<kotlinc>/lib/kotlinx-coroutines-core-jvm.jar:<kotlinc>/lib/kotlin-stdlib.jar CryptoGateCheckKt

kotlinc hex/Hex.kt -include-runtime -d hex.jar
java -jar hex.jar
```

All checks printed PASS on 12.10.2026.
