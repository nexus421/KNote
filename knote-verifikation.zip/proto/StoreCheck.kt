import bayern.kickner.knote.storage.*
import kotnexlib.ResultOf2
import java.nio.file.Files
import kotlin.io.path.listDirectoryEntries
import kotlin.io.path.readText
import kotlin.io.path.writeText

fun check(name: String, ok: Boolean, detail: Any? = "") {
    println((if (ok) "PASS " else "FAIL ") + name + if (ok) "" else "\n  -> $detail")
    if (!ok) System.exit(1)
}

fun main() {
    val dir = Files.createTempDirectory("knote-store")
    val store = (SheetStore.load(dir) as ResultOf2.Success).value
    val now = System.currentTimeMillis()

    val plain = Sheet(SheetStore.newId(), "einkauf", "Einkauf", SheetContent.Plain("# Einkauf\n- Brot"), "sub-123", now, now)
    check("save plain", store.save(plain) is ResultOf2.Success)

    val secret = Sheet(SheetStore.newId(), "privat/notiz", "Privat", encryptContent("geheimer Inhalt", "pw1"), "sub-123", now, now)
    check("save encrypted", store.save(secret) is ResultOf2.Success)

    val dupe = plain.copy(id = SheetStore.newId())
    check("duplicate path rejected", store.save(dupe) is ResultOf2.Failure)

    println("--- stored JSON of the plain sheet ---")
    println(dir.resolve("${plain.id}.json").readText())
    println("--- stored JSON of the encrypted sheet ---")
    println(dir.resolve("${secret.id}.json").readText())

    // Reload from disk
    val reloaded = (SheetStore.load(dir) as ResultOf2.Success).value
    check("reload finds plain", reloaded.find("einkauf") == plain)
    check("reload finds encrypted", reloaded.find("privat/notiz") == secret)
    check("content type survives", reloaded.find("privat/notiz")?.content is SheetContent.Encrypted)

    val ok = decryptContent(reloaded.find("privat/notiz")!!.content, "pw1")
    check("decrypt with right password", ok is ResultOf2.Success && ok.value == "geheimer Inhalt", ok)
    val wrong = decryptContent(reloaded.find("privat/notiz")!!.content, "pw2")
    check("wrong password is WrongPassword", wrong is ResultOf2.Failure && wrong.value == UnlockError.WrongPassword, wrong)
    val notProtected = decryptContent(reloaded.find("einkauf")!!.content, "x")
    check("plain sheet is NotProtected", notProtected is ResultOf2.Failure && notProtected.value == UnlockError.NotProtected)

    // Rename keeps id and drops the old path
    val renamed = plain.copy(path = "einkauf-neu")
    check("rename saved", reloaded.save(renamed) is ResultOf2.Success)
    check("old path gone", reloaded.find("einkauf") == null)
    check("new path found", reloaded.find("einkauf-neu") == renamed)
    check("still two files", dir.listDirectoryEntries("*.json").size == 2)

    // Unknown keys must be rejected at load
    val bad = Files.createTempDirectory("knote-bad")
    bad.resolve("x.json").writeText("""{"id":"x","path":"a","title":"t","content":{"type":"plain","markdown":""},"createdBy":"s","created":1,"updated":1,"extra":true}""")
    val badLoad = SheetStore.load(bad)
    check("unknown key rejected", badLoad is ResultOf2.Failure, badLoad)
    println("  problem: ${(badLoad as ResultOf2.Failure).value}")

    // Invalid path in a file
    val bad2 = Files.createTempDirectory("knote-bad2")
    bad2.resolve("y.json").writeText("""{"id":"y","path":"../etc","title":"t","content":{"type":"plain","markdown":""},"createdBy":"s","created":1,"updated":1}""")
    check("invalid path rejected", SheetStore.load(bad2) is ResultOf2.Failure)

    // Mismatching file name
    val bad3 = Files.createTempDirectory("knote-bad3")
    bad3.resolve("other.json").writeText("""{"id":"z","path":"a","title":"t","content":{"type":"plain","markdown":""},"createdBy":"s","created":1,"updated":1}""")
    check("file name mismatch rejected", SheetStore.load(bad3) is ResultOf2.Failure)

    // Left-over temp files are ignored
    Files.writeString(dir.resolve("leftover.tmp"), "garbage")
    check("tmp files ignored", SheetStore.load(dir) is ResultOf2.Success)

    // Delete
    check("delete", reloaded.delete(secret.id))
    check("deleted path gone", reloaded.find("privat/notiz") == null)

    // Path length
    check("128 chars ok", SheetStore.isValidPath("a".repeat(128)))
    check("129 chars rejected", SheetStore.isValidPath("a".repeat(129)).not())
    println("ALL STORE CHECKS PASSED")
}
