import bayern.kickner.knote.storage.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotnexlib.ResultOf2
import java.util.concurrent.atomic.AtomicInteger
import kotlin.time.measureTime

/** At most this many PBKDF2 derivations run at the same time. */
val cryptoGate = Semaphore(permits = 1)

val running = AtomicInteger(0)
val maxRunning = AtomicInteger(0)

suspend fun unlock(content: SheetContent, password: String) = cryptoGate.withPermit {
    withContext(Dispatchers.Default) {
        maxRunning.accumulateAndGet(running.incrementAndGet(), ::maxOf)
        val result = decryptContent(content, password)
        running.decrementAndGet()
        result
    }
}

fun main() = runBlocking {
    val content = encryptContent("geheim", "pw")
    val took = measureTime {
        (1..4).map { i -> async { unlock(content, if (i == 1) "pw" else "falsch$i") } }.awaitAll()
            .forEachIndexed { i, r -> println("attempt ${i + 1}: ${if (r is ResultOf2.Success) "ok" else (r as ResultOf2.Failure).value}") }
    }
    println("4 attempts with 1 permit took $took, max parallel = ${maxRunning.get()}")
    check(maxRunning.get() == 1) { "gate did not limit parallelism" }
    println("PASS crypto gate limits parallel derivations")
}
