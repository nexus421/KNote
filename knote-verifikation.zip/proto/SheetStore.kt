@file:OptIn(kotnexlib.ExperimentalKotNexLibAPI::class)

package bayern.kickner.knote.storage

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotnexlib.ResultOf2
import kotnexlib.crypto.AES
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.io.path.extension
import kotlin.io.path.listDirectoryEntries
import kotlin.io.path.readText

/** Allowed sheet paths: lowercase segments of a to z, 0 to 9 and hyphen, separated by single slashes. */
val SHEET_PATH_REGEX = Regex("^[a-z0-9-]+(/[a-z0-9-]+)*$")

/** Maximum length of a sheet path in characters. */
const val MAX_PATH_LENGTH = 128

/** One sheet as stored on disk, one JSON file per sheet named after [id]. */
@Serializable
data class Sheet(
    val id: String,
    val path: String,
    val title: String,
    val content: SheetContent,
    val createdBy: String,
    val created: Long,
    val updated: Long,
)

/** Content of a sheet. A protected sheet can only exist encrypted. */
@Serializable
sealed interface SheetContent {
    /** Unprotected Markdown, readable by everyone who knows the path. */
    @Serializable
    @SerialName("plain")
    data class Plain(val markdown: String) : SheetContent

    /** Markdown encrypted with the sheet password, stored as `AES.AESData.toString()`. */
    @Serializable
    @SerialName("encrypted")
    data class Encrypted(val aesData: String) : SheetContent
}

/** Why a sheet could not be unlocked. */
sealed interface UnlockError {
    data object WrongPassword : UnlockError
    data object NotProtected : UnlockError
    data class Corrupt(val reason: String) : UnlockError
}

/** JSON settings for sheet files: readable on disk, unknown keys are errors. */
val sheetJson = Json { prettyPrint = true }

/**
 * Keeps all sheets in memory and writes every change through to [dir] atomically.
 */
class SheetStore private constructor(private val dir: Path, initial: Map<String, Sheet>) {

    private val byPath = ConcurrentHashMap(initial)

    /** All sheets, sorted by path. */
    val all: List<Sheet> get() = byPath.values.sortedBy { it.path }

    /** The sheet at [path], or null. */
    fun find(path: String): Sheet? = byPath[path]

    /** Writes [sheet] to disk first and only then to memory, so memory never shows unsaved state. */
    @Synchronized
    fun save(sheet: Sheet): ResultOf2<Sheet, String> {
        val other = byPath[sheet.path]
        val pathTaken = other != null && other.id != sheet.id
        if (pathTaken) return ResultOf2.Failure("Path ${sheet.path} is already used")

        val written = runCatching {
            val tmp = Files.createTempFile(dir, sheet.id, ".tmp")
            Files.writeString(tmp, sheetJson.encodeToString(Sheet.serializer(), sheet))
            Files.move(tmp, dir.resolve("${sheet.id}.json"), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        }
        if (written.isFailure) return ResultOf2.Failure("Could not write sheet ${sheet.id}: ${written.exceptionOrNull()?.message}")

        // A renamed sheet must not stay reachable under its old path
        byPath.values.removeIf { it.id == sheet.id && it.path != sheet.path }
        byPath[sheet.path] = sheet
        return ResultOf2.Success(sheet)
    }

    /** Deletes the sheet with [id] from disk and memory. */
    @Synchronized
    fun delete(id: String): Boolean {
        val deleted = runCatching { Files.deleteIfExists(dir.resolve("$id.json")) }.getOrDefault(false)
        if (deleted) byPath.values.removeIf { it.id == id }
        return deleted
    }

    companion object {
        /**
         * Loads every `*.json` in [dir]. Fails with all problems at once: unreadable files, invalid paths, and paths
         * used by more than one file. Left-over `*.tmp` files from a crash are ignored.
         */
        fun load(dir: Path): ResultOf2<SheetStore, List<String>> {
            Files.createDirectories(dir)
            val files = dir.listDirectoryEntries().filter { it.extension == "json" }
            val problems = mutableListOf<String>()
            val loaded = files.mapNotNull { file ->
                runCatching { file to sheetJson.decodeFromString(Sheet.serializer(), file.readText()) }
                    .onFailure { problems += "${file.fileName}: ${it.message?.lineSequence()?.first()}" }
                    .getOrNull()
            }
            loaded.filter { (file, sheet) -> file.fileName.toString() != "${sheet.id}.json" }
                .forEach { (file, sheet) -> problems += "${file.fileName}: file name does not match id ${sheet.id}" }
            val sheets = loaded.map { it.second }
            sheets.filter { isValidPath(it.path).not() }.forEach { problems += "${it.id}.json: invalid path '${it.path}'" }
            sheets.groupBy { it.path }.filterValues { it.size > 1 }
                .forEach { (path, dupes) -> problems += "path '$path' used by ${dupes.joinToString { it.id }}" }
            if (problems.isNotEmpty()) return ResultOf2.Failure(problems)
            return ResultOf2.Success(SheetStore(dir, sheets.associateBy { it.path }))
        }

        /** True if [path] is a valid sheet path. */
        fun isValidPath(path: String) = path.length <= MAX_PATH_LENGTH && SHEET_PATH_REGEX.matches(path)

        /** A new random id, also the file name. */
        fun newId(): String = UUID.randomUUID().toString()
    }
}

/** Encrypts [markdown] with [password]. Costs one PBKDF2 derivation (600000 iterations). */
fun encryptContent(markdown: String, password: String): SheetContent.Encrypted =
    SheetContent.Encrypted(AES.GCM.encryptWithPassword(markdown, password, compress = false).toString())

/** Decrypts [content] with [password]. A wrong password is an expected outcome, not an exception. */
fun decryptContent(content: SheetContent, password: String): ResultOf2<String, UnlockError> = when (content) {
    is SheetContent.Plain -> ResultOf2.Failure(UnlockError.NotProtected)
    is SheetContent.Encrypted -> {
        val data = AES.AESData.restore(content.aesData)
        if (data.isFailure) ResultOf2.Failure(UnlockError.Corrupt("stored data cannot be restored"))
        else {
            val plain = data.getOrThrow().decryptAsString(password)
            if (plain.isSuccess) ResultOf2.Success(plain.getOrThrow())
            else if (plain.exceptionOrNull() is javax.crypto.AEADBadTagException) ResultOf2.Failure(UnlockError.WrongPassword)
            else ResultOf2.Failure(UnlockError.Corrupt(plain.exceptionOrNull()?.javaClass?.simpleName ?: "unknown"))
        }
    }
}
