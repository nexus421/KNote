package org.intellij.lang.annotations

/** Local stand-in for the JetBrains annotations artifact, only to compile the serialization runtime offline. */
annotation class Language(val value: String, val prefix: String = "", val suffix: String = "")
